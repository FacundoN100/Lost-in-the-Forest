using UnityEngine;

public class Key : MonoBehaviour, IInteractable
{
    private bool canInteract;

    public bool CanInteract()
    {
        return !canInteract;
    }

    public void Interact()
    {
        canInteract = true;
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (canInteract)
        {
            GameManager.Instance.keyAdd(1);
            Destroy(gameObject);
        }
    }
}
