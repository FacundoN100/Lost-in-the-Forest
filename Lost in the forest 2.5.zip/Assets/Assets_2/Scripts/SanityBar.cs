using UnityEngine;
using UnityEngine.UI;

public class SanityBar : MonoBehaviour
{
    private Image progressBar;
    public float sanity;
    [SerializeField] private float maxSanity;
    public float sanityLossMultiplier;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        progressBar = GetComponent<Image>();
        progressBar.fillAmount = sanity / maxSanity;
    }

    // Update is called once per frame
    void Update()
    {
        progressBar.fillAmount = sanity / maxSanity;
        sanity -= (Time.deltaTime * sanityLossMultiplier);

        SanityCheck();
    }

    private void SanityCheck()
    {
        if (sanity <= 0)
        {
            // call game over
            GameManager.Instance.IrAGameOver();
        }

        if (sanity > maxSanity)
        {
            sanity = maxSanity;
        }
    }
}
