using UnityEngine;
using UnityEngine.UI;

public class Flashlight : MonoBehaviour
{
    private Image progressBar;
    public float battery;
    [SerializeField] private float maxBattery;
    [SerializeField] private GameObject flashlight;
    public bool isOn = true;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        progressBar = GetComponent<Image>();
        progressBar.fillAmount = battery / maxBattery;
    }

    // Update is called once per frame
    void Update()
    {
        if (flashlight.activeInHierarchy)
        {
            progressBar.fillAmount = battery / maxBattery;
            battery -= Time.deltaTime;
        }

        CheckBattery();
    }

    private void CheckBattery()
    {
        if (battery <= 0)
        {
            isOn = false;
            flashlight.SetActive(isOn);
        }
    }
}
