using UnityEngine;

public class Battery : MonoBehaviour, IInteractable
{
    private bool canInteract;
    [SerializeField] private Flashlight flashlight;

    public bool CanInteract()
    {
        return !canInteract;
    }

    public void Interact()
    {
        canInteract = true;
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        flashlight = GetComponent<Flashlight>();
    }

    // Update is called once per frame
    void Update()
    {
        if (canInteract)
        {
            flashlight.battery = 30;
            flashlight.isOn = true;
            Destroy(gameObject);
        }
    }
}
