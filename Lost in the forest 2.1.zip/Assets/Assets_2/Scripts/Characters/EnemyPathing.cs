﻿
using UnityEngine;
using System.Collections;

public class EnemyPathing : MonoBehaviour
{
    private Animator Animator;

    [Header("Patrullaje y Velocidad")]
    [SerializeField] private Transform[] waypoints; 
    [SerializeField] private float moveSpeed = 5f; 
    private float originalSpeed; 

    [Header("Detección y Persecución")] 
    [SerializeField] public float chaseRange = 5f; 
    [SerializeField] private float loseRange = 7f;  
    [SerializeField] private Transform player;      
    private bool isChasing = false; 
    [Header("Interacción con Sigilo")] 
    public bool playerIsHidden = false;

    [Header("Aturdimiento")] 
    private bool isStunned = false; 

    [Header("Distracción")] 
    [SerializeField] private float rayLenght = 10f; 
    [SerializeField] private LayerMask layerMask; 
    private bool isDistracted = false; 
    private Transform distractorTarget; 
    private Vector2 lastDistractorPosition; 
    private bool waitAtDistractor = false; 

    
    void Start()
    {
        Animator = GetComponent<Animator>();
        if (Animator == null)
        {
            Debug.LogWarning("EnemyPathing: No se encontró Animator.", gameObject);
        }

        if (waypoints == null || waypoints.Length == 0 || waypoints[0] == null)
        {
            Debug.LogError("EnemyPathing: ¡Waypoints no asignados o vacíos! No se puede patrullar.", gameObject);
            this.enabled = false;
            return;
        }
        transform.position = waypoints[waypointIndex].position; 

        if (player == null)
        {
            Debug.LogWarning("EnemyPathing: ¡Player no asignado! No se podrá detectar ni perseguir.", gameObject);
        }

        originalSpeed = moveSpeed;
    }

   
    void Update()
    {
        
        if (isStunned) return;

   
        RaycastToDistractor();
        if (isDistracted)
        {
            MoveToDistraction();
            isChasing = false; 
            return; 
        }

        
      
        bool canDetectPlayer = !playerIsHidden && (player != null);

       
        if (canDetectPlayer)
        {
            float distanceToPlayer = Vector2.Distance(transform.position, player.position);

            if (isChasing) 
            {
                if (distanceToPlayer > loseRange) 
                {
                    Debug.Log(gameObject.name + ": Jugador perdido (fuera de rango). Volviendo a patrullar.");
                    isChasing = false;
                }
            }
            else 
            {
                if (distanceToPlayer <= chaseRange) 
                {
                    Debug.Log(gameObject.name + ": Jugador detectado (en rango). Iniciando persecución.");
                    isChasing = true;
                }
            }
        }
        else 
        {
            
            if (isChasing)
            {
                Debug.Log(gameObject.name + ": Jugador se ocultó mientras era perseguido. Deteniendo persecución.");
                isChasing = false;
            }
        }

        
        if (isChasing)
        {
            ChasePlayer(); 
        }
        else 
        {
            Path(); 
        }
    }


    
    private int waypointIndex = 0;
    private void Path()
    {
        if (waypoints.Length == 0) return;

        Vector2 targetPos = waypoints[waypointIndex].position;
        transform.position = Vector2.MoveTowards(transform.position, targetPos, moveSpeed * Time.deltaTime);

        if (Animator != null)
        {
            Vector2 direction = (targetPos - (Vector2)transform.position).normalized;
            if (direction.magnitude > 0.01f)
            {
                Animator.SetFloat("Horizontal", direction.x);
                Animator.SetFloat("Vertical", direction.y);
            }
        }

        // Avanza al siguiente waypoint si está cerca del actual.
        if (Vector2.Distance(transform.position, targetPos) < 0.1f)
        {
            waypointIndex = (waypointIndex + 1) % waypoints.Length;
        }
    }


  
    private void ChasePlayer()
    {
        if (player == null) 
        {
            isChasing = false;
            Debug.LogWarning(gameObject.name + " intentó perseguir pero Player es nulo.");
            return;
        }

        Vector2 direction = (player.position - transform.position).normalized;
        transform.position = Vector2.MoveTowards(transform.position, player.position, moveSpeed * Time.deltaTime);

        if (Animator != null && direction.magnitude > 0.01f)
        {
            Animator.SetFloat("Horizontal", direction.x);
            Animator.SetFloat("Vertical", direction.y);
        }
    }


  
    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log(gameObject.name + " OnCollisionEnter2D con " + collision.gameObject.name + " (Tag: " + collision.collider.tag + ")");

        if (collision.collider.CompareTag("Player"))
        {
            Debug.Log(gameObject.name + " colisionó con Player! Llamando a Morir().");
            PlayerEvents playerEvents = collision.collider.GetComponent<PlayerEvents>();
            if (playerEvents != null)
            {
                playerEvents.Morir(); 
            }
            else
            {
                Debug.LogWarning("Enemigo colisionó con Player, pero no se encontró el script PlayerEvents.", collision.gameObject);
            }
        }
    }


    public void ApplyStun(float duration)
    {
        if (!isStunned)
            StartCoroutine(StunCoroutine(duration));
    }

    private IEnumerator StunCoroutine(float duration)
    {
        Debug.Log(gameObject.name + " ATURDIDO por " + duration + " segundos.");
        isStunned = true;
        isChasing = false;
        isDistracted = false;
        moveSpeed = 0f;
        Animator?.SetBool("IsStunned", true); 
        yield return new WaitForSeconds(duration);
        moveSpeed = originalSpeed;
        isStunned = false;
        Debug.Log(gameObject.name + " Fin del aturdimiento.");
        Animator?.SetBool("IsStunned", false);
    }


    
    private void RaycastToDistractor()
    {
        GameObject distractor = GameObject.FindWithTag("Distractor");
        if (distractor != null)
        {
            Vector2 dirToDistractor = (distractor.transform.position - transform.position).normalized;
            RaycastHit2D hit = Physics2D.Raycast(transform.position, dirToDistractor, rayLenght, layerMask);
            Debug.DrawRay(transform.position, dirToDistractor * rayLenght, Color.yellow); 

            if (hit.collider != null && hit.collider.CompareTag("Distractor"))
            {
                Debug.Log(gameObject.name + ": 🪨 Distractor detectado por raycast en: " + hit.point);
                GoToLastKnownDistractor(hit.point); // Va a investigar.
            }
        }
    }

    public void GoToDistractor(Transform target) // Seguir objeto distractor.
    {
        Debug.Log(gameObject.name + " distraído por objetivo: " + target.name);
        isDistracted = true;
        isChasing = false;
        distractorTarget = target;
        waitAtDistractor = false;
    }

    public void GoToLastKnownDistractor(Vector2 position) // Ir a investigar posición.
    {
        Debug.Log(gameObject.name + " investigando distracción en: " + position);
        isDistracted = true;
        isChasing = false;
        distractorTarget = null;
        lastDistractorPosition = position;
        waitAtDistractor = false;
    }

    private void MoveToDistraction()
    {
        Vector2 targetPosition;
        bool movingToTargetObject = (distractorTarget != null);

        if (movingToTargetObject)
        {
            if (distractorTarget == null) // Si el objeto desapareció.
            {
                Debug.Log(gameObject.name + ": Objetivo de distracción perdido. Deteniendo distracción.");
                isDistracted = false;
                return;
            }
            targetPosition = distractorTarget.position;
        }
        else
        {
            targetPosition = lastDistractorPosition;
        }

        Vector2 dir = (targetPosition - (Vector2)transform.position).normalized;
        transform.position = Vector2.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);

        if (Animator != null && dir.magnitude > 0.01f)
        {
            Animator.SetFloat("Horizontal", dir.x);
            Animator.SetFloat("Vertical", dir.y);
        }

        
        if (!movingToTargetObject && Vector2.Distance(transform.position, lastDistractorPosition) < 0.2f && !waitAtDistractor)
        {
            waitAtDistractor = true;
            StartCoroutine(WaitAtDistractionPoint());
        }
    }

    private IEnumerator WaitAtDistractionPoint()
    {
        Debug.Log(gameObject.name + " llegó al punto de distracción. Esperando...");
        float currentSpeed = moveSpeed;
        moveSpeed = 0f;
        yield return new WaitForSeconds(2f); 
        moveSpeed = currentSpeed; 
        isDistracted = false;
        waitAtDistractor = false;
        Debug.Log(gameObject.name + " terminó de esperar. Volviendo a comportamiento normal.");
    }


    
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow; 
        Gizmos.DrawWireSphere(transform.position, chaseRange);

        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, loseRange);

        if (waypoints != null && waypoints.Length > 0 && waypointIndex < waypoints.Length && waypoints[waypointIndex] != null)
        {
            Gizmos.color = Color.green; 
            Gizmos.DrawLine(transform.position, waypoints[waypointIndex].position);
        }
    }
}