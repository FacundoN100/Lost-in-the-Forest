


using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public Vector2 moveDir;
    [SerializeField] private float moveSpeed = 5f;

    [SerializeField] private GameObject distractorPrefab;
    [SerializeField] private float throwForce = 5f;

    private Rigidbody2D rb;
    private Animator animator;

    [Header("Flashlight")]
    [SerializeField] private Transform flashlightTransform;
    [SerializeField] private GameObject flashlight;
    private bool isOn = true;

    public Vector2 lastDirection = Vector2.down;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        Move();
        Animate();
        UpdateFlashlightDirection();

        if (Input.GetKeyDown(KeyCode.F))
        {
            isOn = !isOn;
            flashlight.SetActive(isOn);
        }

        ThrowDistractor(); // ? usamos el m�todo centralizado
    }

    private void Move()
    {
        float moveX = Input.GetAxisRaw("Horizontal");
        float moveY = Input.GetAxisRaw("Vertical");

        moveDir = new Vector2(moveX, moveY).normalized;

        if (moveDir != Vector2.zero)
            lastDirection = moveDir;

        rb.linearVelocity = moveDir * moveSpeed; // ? corregido: linearVelocity no existe
    }

    private void Animate()
    {
        animator.SetFloat("Horizontal", moveDir.x);
        animator.SetFloat("Vertical", moveDir.y);
        animator.SetFloat("Speed", moveDir.sqrMagnitude);

        if (moveDir == Vector2.zero)
        {
            animator.SetFloat("LastHorizontal", lastDirection.x);
            animator.SetFloat("LastVertical", lastDirection.y);
        }
    }

    private void UpdateFlashlightDirection()
    {
        if (lastDirection == Vector2.up)
            flashlightTransform.rotation = Quaternion.Euler(0, 0, 0);
        else if (lastDirection == Vector2.down)
            flashlightTransform.rotation = Quaternion.Euler(0, 0, 180);
        else if (lastDirection == Vector2.right)
            flashlightTransform.rotation = Quaternion.Euler(0, 0, 270);
        else if (lastDirection == Vector2.left)
            flashlightTransform.rotation = Quaternion.Euler(0, 0, 90);
    }

    private void ThrowDistractor()
    {
        if (Input.GetKeyDown(KeyCode.G))
        {
            if (distractorPrefab == null)
            {
                Debug.LogError(" distractorPrefab no asignado en el Inspector.");
                return;
            }

            float maxDistance = 5f;
            Vector2 direction = lastDirection.normalized;
            Vector2 spawnPos = (Vector2)transform.position + direction * 0.5f;

            GameObject instance = Instantiate(distractorPrefab, spawnPos, Quaternion.identity);

            Rigidbody2D rb = instance.GetComponent<Rigidbody2D>();

            if (rb != null)
            {
                float cappedForce = Mathf.Clamp(throwForce, 0f, maxDistance * 10f);
                rb.AddForce(direction * cappedForce, ForceMode2D.Impulse);
            }

            Destroy(instance, 3f);
        }
    }


}

