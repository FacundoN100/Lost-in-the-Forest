using UnityEngine;

public class Stealth : MonoBehaviour
{
    private Collider2D playerCollider;

    void Awake()
    {
        playerCollider = GetComponent<Collider2D>();
        if (playerCollider == null)
        {
            Debug.LogError("�Stealth requiere un Collider2D en el Jugador!", gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("bushes") && gameObject.CompareTag("Player"))
        {
            if (playerCollider == null) return;
            Debug.Log("JUGADOR (" + gameObject.name + ") ENTR� EN ARBUSTOS.");
            SetEnemyHiddenState(true); // Ocultar y desactivar colisi�n f�sica
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("bushes") && gameObject.CompareTag("Player"))
        {
            if (playerCollider == null) return;
            Debug.Log("JUGADOR (" + gameObject.name + ") SALI� DE ARBUSTOS.");
            SetEnemyHiddenState(false); // Hacer visible y reactivar colisi�n f�sica
        }
    }

    
    private void SetEnemyHiddenState(bool estaOculto)
    {
        if (playerCollider == null)
        {
            Debug.LogWarning("Collider del Jugador no encontrado. Solo se actualizar� la l�gica.");
            UpdateEnemyLogicOnly(estaOculto);
            return;
        }

        EnemyPathing[] enemies = FindObjectsByType<EnemyPathing>(FindObjectsSortMode.None);
        // Debug.Log($"Encontrados {enemies.Length} enemigos para actualizar estado oculto a: {estaOculto}"); // Comentario opcional para depuraci�n

        foreach (EnemyPathing enemy in enemies)
        {
            if (enemy != null && enemy.gameObject.activeInHierarchy)
            {
                // Actualiza la variable de l�gica en el enemigo
                enemy.playerIsHidden = estaOculto;

                // Actualiza la f�sica para ignorar/permitir colisiones
                Collider2D enemyCollider = enemy.GetComponent<Collider2D>();
                if (enemyCollider != null)
                {
                    // Debug.Log($"Estableciendo IgnoreCollision entre {playerCollider.name} y {enemyCollider.name} a: {estaOculto}"); // Comentario opcional para depuraci�n
                    Physics2D.IgnoreCollision(playerCollider, enemyCollider, estaOculto);
                }
                else
                {
                    Debug.LogWarning("Enemigo {enemy.gameObject.name} no tiene Collider2D.", enemy.gameObject);
                }
            }
        }
    }

    // Funci�n de respaldo si falla la obtenci�n del collider del jugador ( la verdad no se si funciona pero lo dejo)
    private void UpdateEnemyLogicOnly(bool estaOculto)
    {
        EnemyPathing[] enemies = FindObjectsByType<EnemyPathing>(FindObjectsSortMode.None);
        foreach (EnemyPathing enemy in enemies)
        {
            if (enemy != null && enemy.gameObject.activeInHierarchy)
            {
                enemy.playerIsHidden = estaOculto;
            }
        }
    }
}