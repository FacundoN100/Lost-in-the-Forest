
using UnityEngine.SceneManagement;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField] private PlayerEvents PlayerMovement;

    private bool juegoTerminado = false;

    private void Start()
    {
        if (PlayerMovement != null)
        {
            PlayerMovement.OnDeath.AddListener(IrAGameOver);
            PlayerMovement.OnVictory.AddListener(IrAVictoria);
        }
        else
        {
            Debug.LogError("Jugador no asignado en GameManager");
        }
    }

    public void IrAGameOver()
    {
        if (!juegoTerminado)
        {
            juegoTerminado = true;
            StartCoroutine(CargarGameOver());
        }
    }

    public void IrAVictoria()
    {
        if (!juegoTerminado)
        {
            juegoTerminado = true;
            StartCoroutine(CargarVictoria());
        }
    }

    private System.Collections.IEnumerator CargarGameOver()
    {
        yield return new WaitForSeconds(0f);
        SceneManager.LoadScene(2); 
    }

    private System.Collections.IEnumerator CargarVictoria()
    {
        yield return new WaitForSeconds(1f);
        SceneManager.LoadScene("NextLevel"); 
    }

    private void OnDestroy()
    {
        if (PlayerMovement != null)
        {
            PlayerMovement.OnDeath.RemoveListener(IrAGameOver);
            PlayerMovement.OnVictory.RemoveListener(IrAVictoria);
        }
    }
}
