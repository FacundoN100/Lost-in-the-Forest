using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Sanity : MonoBehaviour
{
    public float radius = 0.5f;
    public LayerMask layerMask;
    [SerializeField] private SanityBar sanityBar;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        sanityBar = GetComponent<SanityBar>();
    }

    // Update is called once per frame
    void Update()
    {
        if (sanityBar == null)
        {
            sanityBar = GameObject.FindAnyObjectByType<SanityBar>();
        }

        NearEnemy();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Light") && sanityBar != null)
        {
            //sanityBar.sanity += 20;
            sanityBar.ChangeMult(0);
            Debug.Log("A");
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Light") && sanityBar != null)
        {
            sanityBar.ChangeMult(1);
            Debug.Log("B");
        }
    }

    private void NearEnemy()
    {
        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, radius, layerMask);

        foreach (Collider2D collider in colliders)
        {
            if (collider.CompareTag("Enemy"))
            {
                sanityBar.sanity -= 30;
                
            }

            //if (collider.CompareTag("Light"))
            //{
            //    sanityBar.sanity += 75;
            //    sanityBar.sanityLossMultiplier = 0;
            //}
            //else
            //{
            //    sanityBar.sanityLossMultiplier = 1;
            //}
        }
    }
}
