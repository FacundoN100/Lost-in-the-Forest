using UnityEngine;

public class LoadTask : MonoBehaviour
{
    public GameObject task;
    private GameObject currentTask;
    private PlayerMovement player;
    private Vector3 position = new Vector3(0, 0, 5);

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.X))
        {
            if (!player)
            {
                player = FindAnyObjectByType<PlayerMovement>();
            }

            if (currentTask == null)
            {
                currentTask = Instantiate(task, transform);
                currentTask.gameObject.transform.position = transform.position + position;
                player.enabled = false;
            }
            else
            {
                player.enabled = true;
                Destroy(currentTask);
            }
        }
    }
}
