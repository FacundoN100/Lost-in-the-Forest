using UnityEngine;

public class Wire : MonoBehaviour
{
    private Vector3 startPoint;
    private Vector3 startPosition;
    public SpriteRenderer wireEnd;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        startPoint = transform.parent.position;
        startPosition = transform.position;
    }

    private void OnMouseDrag()
    {
        // mouse position to world point
        Vector3 newPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        newPosition.z = 0;

        // check for nearby connection points
        Collider2D[] colliders = Physics2D.OverlapCircleAll(newPosition, 0.2f);
        foreach (Collider2D collider in colliders)
        {
            // make sure not my own collider
            if (collider.gameObject != gameObject)
            {
                // update wire to the connection point position
                UpdateWire(collider.transform.position);

                // check if the wires are the same color
                if (transform.parent.name.Equals(collider.transform.parent.name))
                {
                    // count connection
                    //Counter.Instance.SwitchChange(1);

                    // finish step
                    collider.GetComponent<Wire>()?.Done();
                    Done();
                }
                return;
            }
        }

        // update wire
        UpdateWire(newPosition);
    }

    private void OnMouseUp()
    {
        // reset wire position
        UpdateWire(startPosition);
    }

    private void UpdateWire(Vector3 newPosition)
    {
        // update position
        transform.position = newPosition;

        // update direction
        Vector3 direction = newPosition - startPoint;
        transform.right = direction * transform.lossyScale.x;

        // update scale
        float dist = Vector2.Distance(startPoint, newPosition);
        wireEnd.size = new Vector2(dist, wireEnd.size.y);
    }

    private void Done()
    {
        // destroy the script
        Destroy(this);
    }
}
