using UnityEngine;

public class Counter : MonoBehaviour
{
    static public Counter Instance;
    public int switchCount;
    private int onCount = 0;

    private void Awake()
    {
        Instance = this;
    }

    public void SwitchChange(int points)
    {
        onCount += points;
        if (onCount == switchCount)
        {
            // win text
        }
    }
}
