using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Sanity : MonoBehaviour
{
    public float radius = 0.5f;
    public LayerMask layerMask;
    private SanityBar sanityBar;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        sanityBar = GetComponent<SanityBar>();
    }

    // Update is called once per frame
    void Update()
    {
        NearEnemy();
    }

    //private void OnTriggerStay2D(Collider2D collision)
    //{
    //    if (collision.gameObject.CompareTag("Light"))
    //    {
    //        actualSanityPercent += 20;
    //        Destroy(collision.gameObject);
    //    }
    //}

    private void NearEnemy()
    {
        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, radius, layerMask);

        foreach (Collider2D collider in colliders)
        {
            if (collider.CompareTag("Enemy"))
            {
                sanityBar.sanity -= 30;
                
            }

            if (collider.CompareTag("Light"))
            {
                sanityBar.sanity += 75;
                sanityBar.sanityLossMultiplier = 0;
            }
            else
            {
                sanityBar.sanityLossMultiplier = 1;
            }
        }
    }
}
