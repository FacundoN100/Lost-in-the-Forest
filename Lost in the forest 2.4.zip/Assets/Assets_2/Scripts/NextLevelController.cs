using UnityEngine;

public class NextLevelController : MonoBehaviour
{
    [SerializeField] private SceneLoader loader;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        loader = GetComponent<SceneLoader>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Scene"))
        {
            if (GameManager.Instance.keys == 3)
            {
                loader.ChangeScene("VictoryScene");
            }
        }
    }
}
