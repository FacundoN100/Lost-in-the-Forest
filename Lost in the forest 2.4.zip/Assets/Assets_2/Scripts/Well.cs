using UnityEngine;

public class Well : MonoBehaviour, IInteractable
{
    private bool canInteract;
    private GameObject key;

    bool IInteractable.CanInteract()
    {
        return !canInteract;
    }

    void IInteractable.Interact()
    {
        canInteract = true;
        Instantiate(key);
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
