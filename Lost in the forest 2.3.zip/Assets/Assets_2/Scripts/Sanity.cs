using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Sanity : MonoBehaviour
{
    [SerializeField] private Image sanityBar;
    [SerializeField] private float sanityLossMultiplier = 10;
    private float sanityPercent = 100;
    private float actualSanityPercent = 100;
    public float radius = 0.5f;
    public LayerMask layerMask;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        sanityBar.fillAmount = actualSanityPercent / sanityPercent;
        sanityPercent += sanityLossMultiplier * Time.deltaTime;

        NearEnemy();
    }

    private void SanityCheck()
    {
        if (sanityBar.fillAmount <= 0)
        {
            // call game over
            GameManager.Instance.IrAGameOver();
        }
    }

    //private void OnTriggerStay2D(Collider2D collision)
    //{
    //    if (collision.gameObject.CompareTag("Light"))
    //    {
    //        actualSanityPercent += 20;
    //        Destroy(collision.gameObject);
    //    }
    //}

    private void NearEnemy()
    {
        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, radius, layerMask);

        foreach (Collider2D collider in colliders)
        {
            if (collider.CompareTag("Enemy"))
            {
                actualSanityPercent -= 30;
            }

            if (collider.CompareTag("Light"))
            {
                actualSanityPercent += 50;
            }
        }
    }
}
