using UnityEngine;

public class SpotlightMovement : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 offset;

    [SerializeField] private PlayerMovement player;

    // Update is called once per frame
    void Update()
    {
        transform.position = target.position + offset;
        player.UpdateFlashlightDirection();
    }
}
