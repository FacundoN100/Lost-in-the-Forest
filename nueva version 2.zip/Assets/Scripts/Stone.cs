using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireExtingControls : MonoBehaviour
{
    [SerializeField] private GameObject Flechas;
    [SerializeField] private Transform puntoDeLanzamiento;
    [SerializeField] private float fuerzaLanzamiento = 15f;

    private float lifeTime = 3;
    private GameObject flecha;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            LanzarFlecha();
        }

        lifeTime -= Time.deltaTime;

        if (lifeTime <= 0)
        {
            Destroy(flecha);
        }
    }

    private void LanzarFlecha()
    {
        Vector2 direccion;

        direccion = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")).normalized;

        flecha = Instantiate(Flechas, puntoDeLanzamiento.position, Quaternion.identity);
        Rigidbody2D rb = flecha.GetComponent<Rigidbody2D>();

        if (rb != null)
        {
            Vector2 fuerza = direccion * fuerzaLanzamiento;
            rb.AddForce(fuerza, ForceMode2D.Impulse);
        }
    }
}
