

using UnityEngine;
using UnityEngine.Events;

public class PlayerEvents : MonoBehaviour
{
    public UnityEvent OnDeath;
    public UnityEvent OnVictory;

    public void Morir()
    {
        OnDeath?.Invoke();
    }

    public void Ganar()
    {
        OnVictory?.Invoke();
    }
}
