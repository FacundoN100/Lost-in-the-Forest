
using UnityEngine;
using System.Collections; 



public class EnemyPathing : MonoBehaviour
{
    private Animator Animator;

    [SerializeField] private Transform[] waypoints;
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float chaseRange = 5f;
    [SerializeField] private float loseRange = 7f;
    [SerializeField] private Transform player;

    private int waypointIndex = 0;
    private bool isChasing = false;     
    private float originalSpeed;
    private bool isStunned = false;
    



    void Start()
    {
        Animator = GetComponent<Animator>();
        transform.position = waypoints[waypointIndex].position;
        originalSpeed = moveSpeed;

    }

    void Update()
    {
        float distanceToPlayer = Vector2.Distance(transform.position, player.position);

        if (isChasing)
        {
            if (distanceToPlayer > loseRange)
            {
                isChasing = false;
            }
            else
            {
                ChasePlayer();
                return;
            }
        }
        else
        {
            if (distanceToPlayer <= chaseRange)
            {
                isChasing = true;
                ChasePlayer();
                return;
            }
        }

        Path();
    }

    private void Path()
    {
        if (waypoints.Length == 0) return;

        Vector2 targetPos = waypoints[waypointIndex].position;
        transform.position = Vector2.MoveTowards(transform.position, targetPos, moveSpeed * Time.deltaTime);

        Vector2 direction = (targetPos - (Vector2)transform.position).normalized;
        Animator.SetFloat("Horizontal", direction.x);
        Animator.SetFloat("Vertical", direction.y);

        if (Vector2.Distance(transform.position, targetPos) < 0.1f)
        {
            waypointIndex = (waypointIndex + 1) % waypoints.Length;
        }
    }

    private void ChasePlayer()
    {
        Vector2 direction = (player.position - transform.position).normalized;
        transform.position = Vector2.MoveTowards(transform.position, player.position, moveSpeed * Time.deltaTime);

        Animator.SetFloat("Horizontal", direction.x);
        Animator.SetFloat("Vertical", direction.y);
    }


    /* private void OnTriggerEnter2D(Collider2D other)
     {
         if (other.CompareTag("Player"))
         {
             PlayerEvents playerEvents = other.GetComponent<PlayerEvents>();
             if (playerEvents != null)
             {
                 playerEvents.Morir();
             }
         }
     }*/

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Player"))
        {
            collision.collider.GetComponent<PlayerEvents>()?.Morir();
        }
    }

    public void ApplyStun(float duration)
    {
        if (!isStunned)
            StartCoroutine(StunCoroutine(duration));
    }

    private IEnumerator StunCoroutine(float duration)
    {
        isStunned = true;
        moveSpeed = 0f;
        yield return new WaitForSeconds(duration);
        moveSpeed = originalSpeed;
        isStunned = false;
    }




}
