using UnityEngine.SceneManagement;
using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour
{
    [SerializeField] private PlayerEvents PlayerMovement;

    private bool juegoTerminado = false;

    private int keys = 0;
    public int Keys { get { return keys; } }

    #region singleton
    public static GameManager Instance;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    #endregion

    private void Start()
    {
        if (PlayerMovement != null)
        {
            PlayerMovement.OnDeath.AddListener(IrAGameOver);
            PlayerMovement.OnVictory.AddListener(IrAVictoria);
        }
        else
        {
            Debug.LogError("Jugador no asignado en GameManager");
        }
    }

    public void IrAGameOver()
    {
        if (!juegoTerminado)
        {
            juegoTerminado = true;
            StartCoroutine(CargarGameOver());
        }
    }

    public void IrAVictoria()
    {
        if (!juegoTerminado)
        {
            juegoTerminado = true;
            StartCoroutine(CargarVictoria());
        }
    }

    private IEnumerator CargarGameOver()
    {
        yield return new WaitForSeconds(0f);
        SceneManager.LoadScene(2);
    }

    private IEnumerator CargarVictoria()
    {
        yield return new WaitForSeconds(1f);
        SceneManager.LoadScene("NextLevel");
    }

    private void OnDestroy()
    {
        if (PlayerMovement != null)
        {
            PlayerMovement.OnDeath.RemoveListener(IrAGameOver);
            PlayerMovement.OnVictory.RemoveListener(IrAVictoria);
        }
    }

    public int keyAdd(int key)
    {
        keys += key;
        return keys;
    }

    public string prettyScore()
    {
        return Mathf.RoundToInt(keys).ToString();
    }
}
