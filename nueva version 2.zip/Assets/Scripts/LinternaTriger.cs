using UnityEngine;


public class FlashlightTrigger : MonoBehaviour
{
    [SerializeField] private PlayerMovement player;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Enemy"))
        {
            if (player == null)
                return;

            Vector2 playerLookDir = player.lastDirection.normalized;
            Vector2 toEnemy = ((Vector2)other.transform.position - (Vector2)player.transform.position).normalized;

            float dot = Vector2.Dot(playerLookDir, toEnemy);

            // esto es para cuando esta adentro del cono de luz 

            if (dot >= 0.8f) // si el enemigo esta mirando a la direccion del jugador
            {
                other.GetComponent<EnemyPathing>()?.ApplyStun(2f);// cuanto stun le metemos al loco
            }
        }
    }
}


