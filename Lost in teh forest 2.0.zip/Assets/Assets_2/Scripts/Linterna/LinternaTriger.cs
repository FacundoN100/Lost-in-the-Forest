using UnityEngine;


public class FlashlightTrigger : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Enemy"))
        {
            Transform playerTransform = transform.root; // Busca el objeto ra�z al que pertenece la linterna ose el jugador 
            PlayerMovement movement = playerTransform.GetComponent<PlayerMovement>();

            if (movement == null)
                return;

            Vector2 playerLookDir = movement.lastDirection.normalized;
            Vector2 toEnemy = ((Vector2)other.transform.position - (Vector2)playerTransform.position).normalized;

            float dot = Vector2.Dot(playerLookDir, toEnemy);

            // esto es para cuando esta adentro del cono de luz 

            if (dot >= 0.8f) // si el enemigo esta mirando a la direccion del jugador
            {
                other.GetComponent<EnemyPathing>()?.ApplyStun(2f);// cuanto stun le metemos al loco
            }
        }
    }
}


