using UnityEngine;
using static UnityEngine.RuleTile.TilingRuleOutput;

//public class Distractor : MonoBehaviour
//{
//    [Header("Configuraci�n")]
//    public float lifeTime = 3f;

//    private void Start()
//    {
//        Destroy(gameObject, lifeTime); // destruir esta instancia pasados X segundos
//    }

//    private void OnTriggerEnter2D(Collider2D other)
//    {
//        if (other.CompareTag("Enemy"))
//        {
//            EnemyPathing enemy = other.GetComponent<EnemyPathing>();

//            if (enemy != null)
//            {
//                float distance = Vector2.Distance(enemy.transform.position, transform.position);

//                float distractionRadius = 7f; // alcance de atracci�n del enemigo

//                if (distance <= distractionRadius)
//                {
//                    enemy.GoToDistractor(transform.position);
//                }
//            }
//        }
//    }

//}



public class Distractor : MonoBehaviour
{
    [Header("Configuraci�n")]
    public float lifeTime = 3f;

    private void Start()
    {
        Destroy(gameObject, lifeTime); // destruir esta instancia pasados X segundos
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Enemy"))
        {
            EnemyPathing enemy = other.GetComponent<EnemyPathing>();
            if (enemy != null)
            {
                float distance = Vector2.Distance(transform.position, enemy.transform.position);
                if (distance <= 7f)
                {
                    enemy.GoToDistractor(transform);
                    Debug.Log(" Enemigo detect� distracci�n a distancia " + distance);
                }
            }
        }
    }

    public void DirectionChecker(Vector3 dir)
    {
        if (dir == Vector3.zero) return;

        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(0f, 0f, angle);
    }
}
