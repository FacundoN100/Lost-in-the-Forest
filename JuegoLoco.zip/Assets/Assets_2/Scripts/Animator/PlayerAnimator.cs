

using UnityEngine;

public class PlayerAnimator : MonoBehaviour
{
    private Animator animator;
    private PlayerMovement playerMovement;

    private Vector2 lastDirection = Vector2.down;

    void Start()
    {
        animator = GetComponent<Animator>();
        playerMovement = GetComponent<PlayerMovement>();
    }

    void Update()
    {
        Vector2 moveDir = playerMovement.moveDir;

        if (moveDir != Vector2.zero)
        {
            lastDirection = moveDir;
            PlayWalkAnimation(moveDir);
        }
        else
        {
            PlayIdleAnimation(lastDirection);
        }
    }

    private void PlayWalkAnimation(Vector2 dir)
    {
        if (dir.x > 0)
            animator.Play("Boy-Walk-Right");
        else if (dir.x < 0)
            animator.Play("Boy-Walk-left");
        else if (dir.y > 0)
            animator.Play("Boy-Walk-UP");
        else if (dir.y < 0)
            animator.Play("Boy-Walk");
    }

    private void PlayIdleAnimation(Vector2 dir)
    {
        if (dir.x > 0)
            animator.Play("idle-right-player");
        else if (dir.x < 0)
            animator.Play("idle-left-player");
        else if (dir.y > 0)
            animator.Play("idle-UP-palyer");
        else if (dir.y < 0)
            animator.Play("Boy-Idle-down");
        else
            animator.Play("Boy-idle"); 
    }

}

