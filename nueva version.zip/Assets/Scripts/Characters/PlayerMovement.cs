using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public Vector2 moveDir;
    [SerializeField] private float moveSpeed = 5f;

    private Rigidbody2D rb;
    private Animator animator;

    [Header("Flashlight")]
    [SerializeField] private Transform flashlightTransform;
    [SerializeField] private GameObject flashlight;
    private bool isOn = true;

    private Vector2 lastDirection = Vector2.down;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        Move();
        Animate();
        UpdateFlashlightDirection();

        if (Input.GetKeyDown(KeyCode.F))
        {
            isOn = !isOn;
            flashlight.SetActive(isOn);
        }
    }

    private void Move()
    {
        float moveX = Input.GetAxisRaw("Horizontal");
        float moveY = Input.GetAxisRaw("Vertical");

        moveDir = new Vector2(moveX, moveY).normalized;

        if (moveDir != Vector2.zero)
            lastDirection = moveDir;

        rb.linearVelocity = moveDir * moveSpeed;
    }

    private void Animate()
    {
        animator.SetFloat("Horizontal", moveDir.x);
        animator.SetFloat("Vertical", moveDir.y);
        animator.SetFloat("Speed", moveDir.sqrMagnitude);

        if (moveDir == Vector2.zero)
        {
            animator.SetFloat("LastHorizontal", lastDirection.x);
            animator.SetFloat("LastVertical", lastDirection.y);
        }
    }

    private void UpdateFlashlightDirection()
    {
        if (lastDirection == Vector2.up)
            flashlightTransform.rotation = Quaternion.Euler(0, 0, 0);
        else if (lastDirection == Vector2.down)
            flashlightTransform.rotation = Quaternion.Euler(0, 0, 180);
        else if (lastDirection == Vector2.right)
            flashlightTransform.rotation = Quaternion.Euler(0, 0, 270);
        else if (lastDirection == Vector2.left)
            flashlightTransform.rotation = Quaternion.Euler(0, 0, 90);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Key"))
        {
            GameManager.Instance.keyAdd(1);
            Destroy(collision.gameObject);
        }
    }
}
